# Desynced-Mod-Infinite-Resource-Nodes

![icon](InfiniteResource.png)

Causes all non-tree resource nodes to be nearly infinite.

Only applies to nodes spawned after the mod is loaded.
